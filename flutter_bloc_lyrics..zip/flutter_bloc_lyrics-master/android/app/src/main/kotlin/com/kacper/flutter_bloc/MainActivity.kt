package com.kacper.flutter_bloc

import io.flutter.embedding.android.FlutterActivity;

class MainActivity: FlutterActivity() {

}
